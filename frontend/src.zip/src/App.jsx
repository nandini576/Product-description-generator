import React, { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Home from "./pages/Home";
import About from "./pages/About";
import DashBoard from "./pages/DashBoard";
import Generate from "./pages/Generate";
import Login from "./pages/Login";

function App() {
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [darkMode]);

  return (
    <div className="min-h-screen bg-white dark:bg-slate-950 text-black dark:text-white transition-colors duration-300">
      <BrowserRouter>
        <Routes>
          <Route
            path="/"
            element={<Home darkMode={darkMode} setDarkMode={setDarkMode} />}
          />
          <Route
            path="/about"
            element={<About darkMode={darkMode} setDarkMode={setDarkMode} />}
          />
          <Route
            path="/dashboard"
            element={<DashBoard darkMode={darkMode} setDarkMode={setDarkMode} />}
          />
          <Route
            path="/generate"
            element={<Generate darkMode={darkMode} setDarkMode={setDarkMode} />}
          />
          <Route
            path="/login"
            element={<Login darkMode={darkMode} setDarkMode={setDarkMode} />}
          />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;