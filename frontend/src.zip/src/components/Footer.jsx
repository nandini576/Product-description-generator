function Footer({ darkMode }) {
  return (
    <footer
      className={`text-center py-4 tablet:py-6 mt-8 tablet:mt-10 border-t text-xs tablet:text-sm ${
        darkMode
          ? "bg-slate-900 text-slate-300 border-slate-700"
          : "bg-white text-gray-500 border-gray-200"
      }`}
    >
      <p>© 2026 Product Description Generator</p>

      <p className="mt-1 tablet:mt-2">
        TBI - Graphic Era University |
        Summer Internship Program 2026
      </p>
    </footer>
  );
}

export default Footer;