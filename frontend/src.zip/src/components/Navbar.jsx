import { Link } from "react-router-dom";

function Navbar({ darkMode, setDarkMode }) {
  return (
    <nav
      className={`shadow-md px-3 tablet:px-6 py-3 tablet:py-4 transition-all duration-300 ${
        darkMode
          ? "bg-slate-900 text-white"
          : "bg-white text-black"
      }`}
    >
      <div className="max-w-6xl mx-auto flex justify-between items-center gap-2 tablet:gap-4">

        <h1 className="font-bold text-sm tablet:text-lg desktop:text-xl whitespace-nowrap">
          Product Description Generator
        </h1>

        <div className="flex items-center gap-2 tablet:gap-4 text-xs tablet:text-sm">

          <Link className="hidden tablet:inline" to="/">Home</Link>
          <Link className="hidden tablet:inline" to="/about">About</Link>
          <Link className="hidden tablet:inline" to="/dashboard">Dashboard</Link>
          <Link className="hidden tablet:inline" to="/generate">Generate</Link>
          <Link className="hidden tablet:inline" to="/login">Login</Link>

          <button
            onClick={() => setDarkMode(!darkMode)}
            className={`px-2 tablet:px-3 py-1 tablet:py-2 rounded-lg border text-xs tablet:text-sm whitespace-nowrap ${
              darkMode
                ? "bg-slate-800 border-slate-700"
                : "bg-white border-gray-300"
            }`}
          >
            {darkMode ? "☀️" : "🌙"}
          </button>

        </div>
      </div>
    </nav>
  );
}

export default Navbar;