import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

function About({ darkMode, setDarkMode }) {
  return (
    <>
      <Navbar
        darkMode={darkMode}
        setDarkMode={setDarkMode}
      />

      <main className="max-w-6xl mx-auto px-3 tablet:px-4 desktop:px-6 py-8 tablet:py-12 desktop:py-16 min-h-[70vh]">

        <div className="grid grid-cols-1 tablet:grid-cols-2 gap-6 tablet:gap-8 desktop:gap-12 items-center">

          {/* Image Placeholder */}
          <div
            className={`rounded-2xl h-64 tablet:h-80 desktop:h-80 flex items-center justify-center shadow-sm border ${
              darkMode
                ? "bg-slate-800 border-slate-700"
                : "bg-white border-gray-200"
            }`}
          >
            <div
              className={`w-16 tablet:w-20 desktop:w-20 h-16 tablet:h-20 desktop:h-20 rounded-lg ${
                darkMode
                  ? "bg-slate-700"
                  : "bg-gray-200"
              }`}
            />
          </div>

          {/* Content */}
          <div>

            <h1
              className={`text-2xl tablet:text-3xl desktop:text-4xl font-bold mb-4 tablet:mb-6 ${
                darkMode
                  ? "text-white"
                  : "text-black"
              }`}
            >
              About Us
            </h1>

            <p
              className={`text-sm tablet:text-base desktop:text-base leading-7 tablet:leading-8 mb-4 tablet:mb-6 ${
                darkMode
                  ? "text-slate-300"
                  : "text-gray-600"
              }`}
            >
              We built this tool to help entrepreneurs,
              marketers and e-commerce sellers create
              high-quality product descriptions effortlessly
              using the power of AI.
            </p>

            <p
              className={`leading-8 ${
                darkMode
                  ? "text-slate-300"
                  : "text-gray-600"
              }`}
            >
              Our mission is to make content creation
              faster, smarter and easier for everyone.
            </p>

          </div>

        </div>

      </main>

      <Footer darkMode={darkMode} />
    </>
  );
}

export default About;