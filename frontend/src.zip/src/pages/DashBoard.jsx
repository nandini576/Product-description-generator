import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

function Dashboard({ darkMode, setDarkMode }) {
  const cardStyle = {
    backgroundColor: darkMode ? "#1e293b" : "white",
    color: darkMode ? "white" : "black",
    border: darkMode
      ? "1px solid #334155"
      : "1px solid #e5e7eb",
  };

  const subTextStyle = {
    color: darkMode ? "#cbd5e1" : "#6b7280",
  };

  return (
    <>
      <Navbar
        darkMode={darkMode}
        setDarkMode={setDarkMode}
      />

      <main className="max-w-6xl mx-auto px-6 py-16 min-h-[70vh]">

        <h1
          style={{
            color: darkMode ? "white" : "black",
          }}
          className="text-4xl font-bold"
        >
          Dashboard
        </h1>

        <p
          style={{
            color: darkMode ? "#cbd5e1" : "#6b7280",
          }}
          className="mt-2 mb-10"
        >
          Welcome back! Here's what's happening.
        </p>

        {/* Stats Cards */}

        <div className="grid grid-cols-1 tablet:grid-cols-2 desktop:grid-cols-4 gap-3 tablet:gap-4 desktop:gap-6 mb-8 tablet:mb-10 desktop:mb-12">

          <div
            style={cardStyle}
            className="rounded-xl p-6 shadow-md"
          >
            <p
              style={subTextStyle}
              className="text-sm"
            >
              Total Descriptions
            </p>

            <h2 className="text-3xl font-bold mt-2">
              120
            </h2>
          </div>

          <div
            style={cardStyle}
            className="rounded-xl p-6 shadow-md"
          >
            <p
              style={subTextStyle}
              className="text-sm"
            >
              This Month
            </p>

            <h2 className="text-3xl font-bold mt-2">
              32
            </h2>
          </div>

          <div
            style={cardStyle}
            className="rounded-xl p-6 shadow-md"
          >
            <p
              style={subTextStyle}
              className="text-sm"
            >
              Words Generated
            </p>

            <h2 className="text-3xl font-bold mt-2">
              12.5K
            </h2>
          </div>

          <div
            style={cardStyle}
            className="rounded-xl p-6 shadow-md"
          >
            <p
              style={subTextStyle}
              className="text-sm"
            >
              Time Saved
            </p>

            <h2 className="text-3xl font-bold mt-2">
              8.4 hrs
            </h2>
          </div>

        </div>

        {/* Recent Generations */}

        <div
          style={cardStyle}
          className="rounded-2xl p-6 shadow-md overflow-x-auto"
        >
          <h2 className={`text-lg tablet:text-xl desktop:text-2xl font-semibold mb-4 tablet:mb-6 ${
            darkMode ? "text-white" : "text-black"
          }`}>
            Recent Generations
          </h2>

          <table className="w-full">

            <thead>
              <tr
                style={{
                  borderBottom: darkMode
                    ? "1px solid #334155"
                    : "1px solid #e5e7eb",
                }}
              >
                <th className="text-left py-3">
                  Product Name
                </th>

                <th className="text-left py-3">
                  Category
                </th>

                <th className="text-left py-3">
                  Words
                </th>

                <th className="text-left py-3">
                  Created At
                </th>

                <th className="text-left py-3">
                  Status
                </th>
              </tr>
            </thead>

            <tbody>

              <tr
                style={{
                  borderBottom: darkMode
                    ? "1px solid #334155"
                    : "1px solid #e5e7eb",
                }}
              >
                <td className="py-4">
                  Wireless Headphones
                </td>

                <td>Electronics</td>

                <td>150</td>

                <td>21 Jun 2026</td>

                <td className="text-green-600">
                  Completed
                </td>
              </tr>

              <tr
                style={{
                  borderBottom: darkMode
                    ? "1px solid #334155"
                    : "1px solid #e5e7eb",
                }}
              >
                <td className="py-4">
                  Protein Powder
                </td>

                <td>Health</td>

                <td>120</td>

                <td>20 Jun 2026</td>

                <td className="text-green-600">
                  Completed
                </td>
              </tr>

              <tr>
                <td className="py-4">
                  Coffee Mug
                </td>

                <td>Kitchen</td>

                <td>90</td>

                <td>19 Jun 2026</td>

                <td className="text-green-600">
                  Completed
                </td>
              </tr>

            </tbody>

          </table>
        </div>

      </main>

      <Footer />
    </>
  );
}

export default Dashboard;