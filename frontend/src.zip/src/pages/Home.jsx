import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { motion } from "framer-motion";

function Home({ darkMode, setDarkMode }) {
  return (
    <>
      <Navbar
        darkMode={darkMode}
        setDarkMode={setDarkMode}
      />

      <main className="max-w-5xl mx-auto px-3 tablet:px-4 desktop:px-6 py-8 tablet:py-12 desktop:py-16 min-h-[70vh]">
        {/* Hero Section */}
        <section className="text-center">

          <motion.h1
            initial={{ opacity: 0, y: -40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className={`text-2xl tablet:text-4xl desktop:text-6xl font-bold ${
              darkMode ? "text-white" : "text-black"
            }`}
          >
            Generate Product Descriptions with AI
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.3 }}
            className={`mt-4 tablet:mt-6 text-sm tablet:text-base desktop:text-lg ${
              darkMode
                ? "text-slate-300"
                : "text-gray-500"
            }`}
          >
            Create engaging product descriptions
            in seconds using AI.
          </motion.p>

        </section>

        {/* Cards */}
        <section className="grid grid-cols-1 tablet:grid-cols-2 gap-4 tablet:gap-6 desktop:gap-8 mt-8 tablet:mt-12 desktop:mt-16">

          <motion.div
            animate={{
              y: [0, -10, 0],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className={`shadow-md rounded-2xl p-8 ${
              darkMode
                ? "bg-slate-800 text-white"
                : "bg-white text-black"
            }`}
          >
            <div
              className={`w-12 h-12 rounded-lg mb-4 ${
                darkMode
                  ? "bg-slate-700"
                  : "bg-gray-200"
              }`}
            ></div>

            <h2 className="font-semibold text-xl">
              AI Powered
            </h2>

            <p
              className={`mt-2 ${
                darkMode
                  ? "text-slate-300"
                  : "text-gray-500"
              }`}
            >
              Generate descriptions instantly
              with advanced AI technology.
            </p>
          </motion.div>

          <motion.div
            animate={{
              y: [0, -10, 0],
            }}
            transition={{
              duration: 3,
              delay: 1,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className={`shadow-md rounded-2xl p-8 ${
              darkMode
                ? "bg-slate-800 text-white"
                : "bg-white text-black"
            }`}
          >
            <div
              className={`w-12 h-12 rounded-lg mb-4 ${
                darkMode
                  ? "bg-slate-700"
                  : "bg-gray-200"
              }`}
            ></div>

            <h2 className="font-semibold text-xl">
              E-Commerce Ready
            </h2>

            <p
              className={`mt-2 ${
                darkMode
                  ? "text-slate-300"
                  : "text-gray-500"
              }`}
            >
              Optimized descriptions for Amazon,
              Shopify and other marketplaces.
            </p>
          </motion.div>

        </section>

      </main>

      <Footer darkMode={darkMode} />
    </>
  );
}

export default Home;