import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
function Login({darkMode,setDarkMode}) {
  return (
    <>
      <Navbar darkMode={darkMode} setDarkMode={setDarkMode} />
   <main className="max-w-6xl mx-auto px-3 tablet:px-4 desktop:px-6 py-8 tablet:py-12 desktop:py-16 min-h-[70vh] flex justify-center">

  <div
    className={`w-full max-w-sm tablet:max-w-md desktop:max-w-md shadow-sm border rounded-2xl p-6 tablet:p-8 desktop:p-8 ${
      darkMode
        ? "bg-slate-800 border-slate-700 text-white"
        : "bg-white border-gray-200 text-black"
    }`}
  >

    <h1 className="text-xl tablet:text-2xl font-bold text-center mb-6 tablet:mb-8">
      Login to your account
    </h1>

    <div className="space-y-3 tablet:space-y-4 desktop:space-y-5">

      <div>
        <label className="block text-xs tablet:text-sm mb-2">
          Email
        </label>

        <input
          type="email"
          placeholder="Enter your email"
          className={`w-full rounded-lg px-4 py-2 border text-xs tablet:text-sm ${
            darkMode
              ? "bg-slate-900 border-slate-700 text-white"
              : "bg-white border-gray-300 text-black"
          }`}
        />
      </div>

      <div>
        <label className="block text-xs tablet:text-sm mb-2">
          Password
        </label>

        <input
          type="password"
          placeholder="Enter your password"
          className={`w-full rounded-lg px-4 py-2 border text-xs tablet:text-sm ${
            darkMode
              ? "bg-slate-900 border-slate-700 text-white"
              : "bg-white border-gray-300 text-black"
          }`}
        />
      </div>

      <button
        className={`w-full py-2 rounded-lg ${
          darkMode
            ? "bg-slate-900 text-white"
            : "bg-gray-800 text-white"
        }`}
      >
        Login
      </button>

      <p className="text-center text-sm opacity-70">
        Don't have an account?
        <span className="font-semibold ml-1 cursor-pointer">
          Sign Up
        </span>
      </p>

    </div>

  </div>

</main>
      <Footer darkMode={darkMode} />
    </>
  );
}

export default Login;